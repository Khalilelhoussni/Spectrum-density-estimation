findthreshandstep=function(epsi,nu){
  polyalphanu=function(alpha,nu, epsi){
    alpha^(2-nu)+2*alpha+alpha^nu+2*epsi*(nu-1)
  }
  ###\alpha \in (0, epsi *(1-nu)/2]
  alpha=uniroot(polyalphanu,c(0,epsi*(1-nu)/2), epsi=epsi, nu=nu)$root 
  u=alpha/2+epsi/(1+alpha^(1-nu))
  return(c(alpha,u))
}

nonzerosol=function(y,epsi,nu,phikappa){
  grad=function(x,y,epsi,nu){
    y=abs(y)
    tp=x^(1-nu)
    x-y+epsi*(1+nu*tp)/(1+tp)^2
  }
  #alpha=uniroot(grad,c(phikappa[1],abs(y)), y=y, epsi=epsi, nu=nu)$root
  alpha=multiroot(grad,start=phikappa[1]+abs(y), y=y, epsi=epsi, nu=nu)$root
  alpha=alpha*sign(y)
  return(alpha)
}

thresholdfct=function(y,epsi,nu){
  if(nu<1) alphau=findthreshandstep(epsi,nu)
  else alphau=c(0, epsi)
  sol=rep(0,length(y))
  ind=(abs(y)>=alphau[2])
  #if(abs(y)<alphau[2]) sol=0
  #else sol=nonzerosol(y,epsi,nu,alphau)
  yind=y[ind]
  if(nu<1) sol[ind]=nonzerosol(yind,epsi,nu,alphau)
  else sol[ind]=sign(yind)*pmax(abs(yind)-epsi,0)
  return(sol)
}

